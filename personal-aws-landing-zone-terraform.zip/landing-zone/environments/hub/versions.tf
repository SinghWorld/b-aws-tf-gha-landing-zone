terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Remote state - matches your existing GitOps pattern (S3 backend).
  # Create this bucket + DynamoDB lock table manually once before first init,
  # or via a small bootstrap config applied with local state first.
  backend "s3" {
    bucket         = "balraj-personal-lab-tfstate"
    key            = "landing-zone/terraform.tfstate"
    region         = "ap-southeast-2"
    dynamodb_table = "terraform-state-lock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project   = "personal-landing-zone"
      ManagedBy = "terraform"
    }
  }
}
